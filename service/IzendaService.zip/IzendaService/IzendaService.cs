﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Timers;

namespace IzendaService
{
  public partial class IzendaService : ServiceBase
  {
		string url;
    public IzendaService()
    {
      InitializeComponent();
    }

    private Timer timer;

    private void RunScheduledReports(object sender, ElapsedEventArgs elapsedEventArgs)
    {
      timer.Stop();
      string executeResult;
      try {
        string schedulingLogs = "";
        using (WebClient wc = new WebClient()) {
					using (Stream s = wc.OpenRead(url))
					{
            StringBuilder sb = new StringBuilder();
            if (s != null) {
              byte[] buf = new byte[1024];
              int read = s.Read(buf, 0, 1024);
              while (read > 0) {
                sb.Append(Encoding.UTF8.GetChars(buf));
                read = s.Read(buf, 0, 1024);
              }
              schedulingLogs = sb.ToString();
            }
          }
        }
        executeResult = "Scheduling operation succeeded. Log which can be parsed: " + schedulingLogs;
      }
      catch (Exception e) {
        executeResult = "Scheduling operation failed: " + e.Message;
      }
      Log(executeResult);
      timer.Start();
    }

    protected override void OnStart(string[] args)
    {
			url = System.Configuration.ConfigurationSettings.AppSettings["url"].ToString();
			int interval = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["interval"].ToString());

			timer = new Timer(interval);
      timer.Elapsed += RunScheduledReports;
      RunScheduledReports(null, null);
      Log("IzendaService started");
    }

    protected override void OnStop()
    {
      timer.Stop();
      timer.Close();
      Log("IzendaService stopped");
    }

    public void Log(string log)
    {
      try {
        if (!EventLog.SourceExists("IzendaService"))
          EventLog.CreateEventSource("IzendaService", "IzendaService");
        eventLog1.Source = "IzendaService";
        eventLog1.WriteEntry(log);
      }
      catch { }
    }
  }
}
